Pure python bindings for augeas http://augeas.net/.
